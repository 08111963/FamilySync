import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { getParam } from '../lib/http-params';
import type { Request, Response } from 'express';
import { z } from 'zod';
import { db } from '../db';
import { families, familyMembers, familyInvites, users, calendarEvents, shoppingItems, shoppingLists, chores } from '../../shared/schema';
import { eq, and, isNull, sql } from 'drizzle-orm';
import { authenticate } from '../middleware/auth';
import { requireFamilyMember, requireFamilyAdmin } from '../middleware/family';
import { sendFamilyInviteEmail, isEmailConfigured } from '../lib/email';
import { broadcastToFamily } from '../lib/websocket';
import { config } from '../lib/config';
import { logger } from '../lib/logger';
import { generateInviteToken, hashInviteToken } from '../lib/invite-token';

const router = Router();

const createFamilySchema = z.object({
  name: z.string().min(1, "Il nome è obbligatorio").max(50),
  colorTheme: z.string().optional().default("#6366F1"),
});

const updateFamilySchema = z.object({
  name: z.string().min(2, "Il nome deve avere almeno 2 caratteri").max(50).optional(),
  colorTheme: z.string().optional(),
});

const inviteSchema = z.object({
  email: z.string().trim().toLowerCase().email("Email non valida"),
  invitedName: z.string().trim().max(255).optional(),
  role: z.enum(["admin", "adult", "teen", "child"]).optional().default("adult"),
});

const INVITE_TTL_MS = 72 * 60 * 60 * 1000;

// Rate limiter dedicato alla creazione inviti: più stretto del limiter globale /api,
// per evitare abusi di invio email (enumerazione / spam) anche da admin compromessi.
const createInviteLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
});

router.post('/', authenticate, async (req: Request, res: Response) => {
  try {
    const parsed = createFamilySchema.safeParse(req.body);

    if (!parsed.success) {
      return res.status(400).json({
        error: { code: "VALIDATION_ERROR", message: "Dati non validi", details: parsed.error.flatten().fieldErrors },
      });
    }

    const [family] = await db.insert(families).values({
      name: parsed.data.name,
      colorTheme: parsed.data.colorTheme,
    }).returning();

    await db.insert(familyMembers).values({
      familyId: family.id,
      userId: req.user!.userId,
      role: 'admin',
      nickname: 'Admin',
      color: '#6366F1',
      points: 0,
    });

    res.status(201).json(family);
  } catch (error) {
    logger.error('Create family error', { error: String(error) });
    res.status(500).json({ error: { code: "SERVER_ERROR", message: "Errore nella creazione della famiglia" } });
  }
});

router.get('/', authenticate, async (req: Request, res: Response) => {
  try {
    const myFamilies = await db
      .select({ family: families, member: familyMembers })
      .from(familyMembers)
      .innerJoin(families, eq(familyMembers.familyId, families.id))
      .where(eq(familyMembers.userId, req.user!.userId));

    res.json(myFamilies.map(f => ({ ...f.family, myRole: f.member.role, myMemberId: f.member.id })));
  } catch (error) {
    logger.error('Get families error', { error: String(error) });
    res.status(500).json({ error: { code: "SERVER_ERROR", message: "Errore nel recupero delle famiglie" } });
  }
});

router.get('/:familyId', authenticate, requireFamilyMember(), async (req: Request, res: Response) => {
  try {
    const familyId = getParam(req, 'familyId');

    const [family] = await db.select().from(families).where(eq(families.id, familyId)).limit(1);

    if (!family) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Famiglia non trovata" } });
    }

    const members = await db
      .select({ member: familyMembers, user: users })
      .from(familyMembers)
      .innerJoin(users, eq(familyMembers.userId, users.id))
      .where(eq(familyMembers.familyId, familyId));

    const [eventsCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(calendarEvents)
      .where(and(eq(calendarEvents.familyId, familyId), isNull(calendarEvents.createdBy)));

    const [itemsCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(shoppingItems)
      .innerJoin(shoppingLists, eq(shoppingItems.listId, shoppingLists.id))
      .where(and(eq(shoppingLists.familyId, familyId), isNull(shoppingItems.createdBy)));

    const [choresCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(chores)
      .where(and(eq(chores.familyId, familyId), isNull(chores.createdBy)));

    console.log(JSON.stringify({
      tag: "LEGACY_NULL_CREATED_BY",
      familyId,
      counts: { events: eventsCount.count, shoppingItems: itemsCount.count, chores: choresCount.count }
    }));

    res.json({
      ...family,
      members: members.map(m => ({
        id: m.member.id,
        userId: m.user.id,
        name: m.user.name,
        nickname: m.member.nickname,
        role: m.member.role,
        color: m.member.color,
        points: m.member.points,
        avatarUrl: m.user.avatarUrl,
      })),
    });
  } catch (error) {
    logger.error('Get family detail error', { error: String(error) });
    res.status(500).json({ error: { code: "SERVER_ERROR", message: "Errore nel recupero della famiglia" } });
  }
});

router.put('/:familyId', authenticate, requireFamilyAdmin(), async (req: Request, res: Response) => {
  try {
    const familyId = getParam(req, 'familyId');
    const parsed = updateFamilySchema.safeParse(req.body);

    if (!parsed.success) {
      return res.status(400).json({
        error: { code: "VALIDATION_ERROR", message: "Dati non validi", details: parsed.error.flatten().fieldErrors },
      });
    }

    const [updatedFamily] = await db.update(families)
      .set({ ...parsed.data, updatedAt: new Date() })
      .where(eq(families.id, familyId))
      .returning();

    broadcastToFamily(familyId, 'family_updated', updatedFamily);
    res.json(updatedFamily);
  } catch (error) {
    logger.error('Update family error', { error: String(error) });
    res.status(500).json({ error: { code: "SERVER_ERROR", message: "Errore nell'aggiornamento della famiglia" } });
  }
});

router.post('/:familyId/invite', createInviteLimiter, authenticate, requireFamilyAdmin(), async (req: Request, res: Response) => {
  try {
    const familyId = getParam(req, 'familyId');
    const parsed = inviteSchema.safeParse(req.body);

    if (!parsed.success) {
      return res.status(400).json({
        error: { code: "VALIDATION_ERROR", message: "Dati non validi", details: parsed.error.flatten().fieldErrors },
      });
    }

    const { email, invitedName, role } = parsed.data;

    // In produzione l'invio email è obbligatorio: senza SendGrid non possiamo
    // recapitare il link, quindi non creiamo nemmeno l'invito.
    if (config.isProduction && !isEmailConfigured()) {
      return res.status(503).json({
        error: { code: "EMAIL_NOT_CONFIGURED", message: "Il servizio email non è configurato. Impossibile inviare l'invito." },
      });
    }

    const [family] = await db.select().from(families).where(eq(families.id, familyId)).limit(1);
    const [inviter] = await db.select().from(users).where(eq(users.id, req.user!.userId)).limit(1);

    // Se esiste già un membro con quell'email nella famiglia, evitiamo l'invito.
    const [existingUser] = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (existingUser) {
      const [alreadyMember] = await db.select()
        .from(familyMembers)
        .where(and(eq(familyMembers.familyId, familyId), eq(familyMembers.userId, existingUser.id)))
        .limit(1);
      if (alreadyMember) {
        return res.status(409).json({ error: { code: "ALREADY_MEMBER", message: "Questa persona fa già parte della famiglia" } });
      }
    }

    const token = generateInviteToken();
    const tokenHash = hashInviteToken(token);
    const expiresAt = new Date(Date.now() + INVITE_TTL_MS);

    const [createdInvite] = await db.insert(familyInvites).values({
      familyId,
      tokenHash,
      email,
      invitedName: invitedName || null,
      invitedBy: req.user!.userId,
      role,
      expiresAt,
    }).returning();

    const baseUrl = process.env.CLIENT_URL || config.getBaseUrl(req);
    const inviteLink = `${baseUrl}/join/${token}`;

    try {
      await sendFamilyInviteEmail(email, family.name, inviter.name, inviteLink, invitedName);
    } catch (mailError) {
      logger.error('Invite email send failed', { error: String(mailError) });
      // In produzione un fallimento di invio è bloccante: l'invito non è
      // recapitabile, quindi facciamo rollback per non lasciare token orfani.
      if (config.isProduction) {
        await db.delete(familyInvites).where(eq(familyInvites.id, createdInvite.id));
        return res.status(502).json({
          error: { code: "EMAIL_SEND_FAILED", message: "Invio email fallito. Riprova più tardi." },
        });
      }
    }

    // Non logghiamo mai token o link completi.
    logger.info('Family invite created', { familyId, role });

    const response: Record<string, unknown> = { ok: true, email, expiresAt };
    // Solo in sviluppo restituiamo il link per comodità di test manuale.
    if (!config.isProduction) {
      response.inviteLink = inviteLink;
    }
    res.json(response);
  } catch (error) {
    logger.error('Create invite error', { error: String(error) });
    res.status(500).json({ error: { code: "SERVER_ERROR", message: "Errore nella creazione dell'invito" } });
  }
});

router.post('/join/:token', authenticate, async (req: Request, res: Response) => {
  try {
    const token = getParam(req, 'token');
    const { nickname, color } = req.body;
    const tokenHash = hashInviteToken(token);

    const [invite] = await db.select()
      .from(familyInvites)
      .where(eq(familyInvites.tokenHash, tokenHash))
      .limit(1);

    if (!invite) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Invito non trovato" } });
    }

    if (invite.acceptedAt) {
      return res.status(409).json({ error: { code: "ALREADY_ACCEPTED", message: "Invito già accettato" } });
    }

    if (new Date() > invite.expiresAt) {
      return res.status(400).json({ error: { code: "INVITE_EXPIRED", message: "Invito scaduto" } });
    }

    // L'email dell'utente loggato deve coincidere con quella invitata.
    const [currentUser] = await db.select().from(users).where(eq(users.id, req.user!.userId)).limit(1);
    if (!currentUser || currentUser.email.toLowerCase() !== invite.email.toLowerCase()) {
      return res.status(403).json({
        error: { code: "EMAIL_MISMATCH", message: "Questo invito è destinato a un altro indirizzo email" },
      });
    }

    const existing = await db.select()
      .from(familyMembers)
      .where(and(eq(familyMembers.familyId, invite.familyId), eq(familyMembers.userId, req.user!.userId)))
      .limit(1);

    if (existing.length > 0) {
      return res.status(409).json({ error: { code: "ALREADY_MEMBER", message: "Fai già parte di questa famiglia" } });
    }

    // Consumo monouso + creazione membership nella STESSA transazione: se l'insert
    // del membro fallisce, il claim del token viene annullato (rollback atomico).
    const txResult = await db.transaction(async (tx) => {
      const claimed = await tx.update(familyInvites)
        .set({ acceptedAt: new Date(), acceptedByUserId: req.user!.userId })
        .where(and(eq(familyInvites.id, invite.id), isNull(familyInvites.acceptedAt)))
        .returning();

      if (claimed.length === 0) {
        return { conflict: true as const };
      }

      const [member] = await tx.insert(familyMembers).values({
        familyId: invite.familyId,
        userId: req.user!.userId,
        role: invite.role,
        nickname: nickname || invite.invitedName || currentUser.name || 'Membro',
        color: color || '#6366F1',
        points: 0,
      }).returning();

      return { conflict: false as const, member };
    });

    if (txResult.conflict) {
      return res.status(409).json({ error: { code: "ALREADY_ACCEPTED", message: "Invito già accettato" } });
    }

    const newMember = txResult.member;
    const [family] = await db.select().from(families).where(eq(families.id, invite.familyId)).limit(1);

    broadcastToFamily(invite.familyId, 'member_joined', newMember);

    res.json({ message: 'Invito accettato!', family });
  } catch (error) {
    logger.error('Accept invite error', { error: String(error) });
    res.status(500).json({ error: { code: "SERVER_ERROR", message: "Errore nell'accettazione dell'invito" } });
  }
});

router.put('/:familyId/members/:memberId', authenticate, requireFamilyMember(), async (req: Request, res: Response) => {
  try {
    const familyId = getParam(req, 'familyId');
    const memberId = getParam(req, 'memberId');
    const { nickname, color, role } = req.body;
    const membership = (req as any).membership;

    const updateData: any = {};
    if (nickname) updateData.nickname = nickname;
    if (color) updateData.color = color;

    if (role && membership.role === 'admin') {
      updateData.role = role;
    }

    const [updated] = await db.update(familyMembers)
      .set(updateData)
      .where(and(eq(familyMembers.id, memberId), eq(familyMembers.familyId, familyId)))
      .returning();

    broadcastToFamily(familyId, 'member_updated', updated);
    res.json(updated);
  } catch (error) {
    logger.error('Update member error', { error: String(error) });
    res.status(500).json({ error: { code: "SERVER_ERROR", message: "Errore nell'aggiornamento del membro" } });
  }
});

router.delete('/:familyId/members/:memberId', authenticate, requireFamilyAdmin(), async (req: Request, res: Response) => {
  try {
    const familyId = getParam(req, 'familyId');
    const memberId = getParam(req, 'memberId');

    await db.delete(familyMembers)
      .where(and(eq(familyMembers.id, memberId), eq(familyMembers.familyId, familyId)));

    broadcastToFamily(familyId, 'member_removed', { memberId });
    res.json({ message: 'Membro rimosso' });
  } catch (error) {
    logger.error('Remove member error', { error: String(error) });
    res.status(500).json({ error: { code: "SERVER_ERROR", message: "Errore nella rimozione del membro" } });
  }
});

export default router;
