# Revisione gestione password - FamilySync

NOTA: server/lib/email.ts, server/lib/config.ts e app/change-password.tsx sono
inclusi SOLO come contesto di verifica: NON sono stati modificati in questo task.
shared/schema.ts e package.json NON sono stati modificati (nessuna dipendenza o
script aggiunto), quindi non sono inclusi.

## Mappa dei 10 punti di verifica
1. Token reset salvato solo hashato      -> server/routes/auth.ts (insert tokenHash) + server/lib/reset-token.ts (SHA-256)
2. Token monouso                          -> server/routes/auth.ts (/reset-password: DELETE ... RETURNING atomico)
3. Token con scadenza                     -> server/routes/auth.ts (expiresAt 1h; check TOKEN_EXPIRED)
4. Risposta generica anti-enumeration     -> server/routes/auth.ts (/request-password-reset: genericMessage su ogni ramo, incl. fallimento invio email)
5. Reset non restituisce mai password     -> server/routes/auth.ts + test
6. Email reset contiene solo link         -> server/lib/email.ts (sendPasswordResetEmail) + test
7. SendGrid obbligatorio in produzione    -> server/routes/auth.ts (config.isProduction && !isEmailConfigured -> EMAIL_NOT_CONFIGURED) + config.ts + email.ts
8. Cambio password richiede attuale       -> server/routes/auth.ts (/change-password) + app/change-password.tsx
9. forgot/reset pubbliche in AuthGate     -> app/_layout.tsx (inPublicGroup + esclusioni redirect)
10. Nessuna password loggata/restituita   -> server/routes/auth.ts (logger solo errori; nessun campo password nelle risposte) + test
