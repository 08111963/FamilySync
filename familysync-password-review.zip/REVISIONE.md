# Revisione gestione password + configurazione email produzione - FamilySync

NOTA: server/lib/config.ts e app/change-password.tsx sono inclusi come contesto
di verifica (non modificati in questo task). server/routes/families.ts incluso
per mostrare il flusso invito (link con fallback CLIENT_URL || getBaseUrl(req),
quindi mai rotto). shared/schema.ts e package.json NON modificati.

## Fix configurazione email/CLIENT_URL (questo giro)
- server/lib/email.ts: env lette a RUNTIME (apiKey/fromAddress/clientBaseUrl).
  Nuove funzioni: isLinkEmailConfigured(), isPasswordResetEmailConfigured(),
  isVerificationEmailConfigured(). I link usano clientBaseUrl() -> mai "undefined/...".
- server/routes/auth.ts:
  - /request-password-reset: in prod richiede SendGrid E CLIENT_URL (isPasswordResetEmailConfigured), altrimenti 503 EMAIL_NOT_CONFIGURED PRIMA di toccare il DB.
  - /signup: in prod, se email non configurata, NON blocca ma salta l'invio (warning), niente link rotto.
  - /resend-verification-email: in prod, se email non configurata, 503 EMAIL_NOT_CONFIGURED.
- server/__tests__/password.test.ts: +5 test (prod SendGrid sì/CLIENT_URL no, prod SendGrid no, prod entrambi ok, link basato su CLIENT_URL, signup non-bloccante, resend bloccante). Totale 17 test verdi.

## Mappa dei 10 punti di verifica originali
1. Token reset salvato solo hashato      -> server/routes/auth.ts + server/lib/reset-token.ts (SHA-256)
2. Token monouso                          -> server/routes/auth.ts (DELETE ... RETURNING atomico)
3. Token con scadenza                     -> server/routes/auth.ts (expiresAt 1h; TOKEN_EXPIRED)
4. Risposta generica anti-enumeration     -> server/routes/auth.ts (genericMessage su ogni ramo)
5. Reset non restituisce mai password     -> server/routes/auth.ts + test
6. Email reset contiene solo link         -> server/lib/email.ts + test (link == CLIENT_URL/...)
7. SendGrid obbligatorio in produzione    -> server/routes/auth.ts (ORA anche CLIENT_URL) + email.ts
8. Cambio password richiede attuale       -> server/routes/auth.ts + app/change-password.tsx
9. forgot/reset pubbliche in AuthGate     -> app/_layout.tsx
10. Nessuna password loggata/restituita   -> server/routes/auth.ts + test
